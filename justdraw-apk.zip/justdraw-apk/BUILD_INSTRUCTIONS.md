# JustDraw – הוראות בנייה ל-APK

## דרישות מקדימות

| כלי | גרסה מינימלית | הורדה |
|-----|--------------|-------|
| Node.js | 18+ | https://nodejs.org |
| JDK | 17 (OpenJDK / Temurin) | https://adoptium.net |
| Android SDK | API 34 | דרך Android Studio |
| Cordova CLI | 12 | `npm install -g cordova` |

### משתני סביבה נדרשים
```bash
export JAVA_HOME=/path/to/jdk17
export ANDROID_HOME=/path/to/android-sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

---

## שלבי בנייה (פעם ראשונה)

```bash
# 1. כנס לתיקיית הפרויקט
cd justdraw-apk

# 2. התקן תלויות Node
npm install

# 3. הוסף פלטפורמת Android
cordova platform add android

# 4. התקן פלאגינים
cordova plugin add cordova-plugin-file
cordova plugin add cordova-plugin-file-opener2
cordova plugin add cordova-plugin-camera
cordova plugin add cordova-plugin-media-capture

# 5. בנה APK לבדיקה (debug)
cordova build android

# הקובץ נמצא ב:
# platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

---

## בנייה ל-Release (לחנות / שיתוף)

```bash
# בנה APK release (לא חתום)
cordova build android --release

# הקובץ: platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk

# חתימה (נדרש keystore):
keytool -genkey -v -keystore justdraw.keystore \
        -alias justdraw -keyalg RSA -keysize 2048 -validity 10000

apksigner sign --ks justdraw.keystore \
               --ks-key-alias justdraw \
               --out justdraw-signed.apk \
               app-release-unsigned.apk
```

---

## התקנה על מכשיר (ADB)

```bash
# וודא שה-USB Debugging מופעל במכשיר
adb devices
adb install platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

---

## מה עובד ב-APK

| תכונה | מנגנון |
|-------|--------|
| ציור ולוח בדיוק כמו בדפדפן | HTML5 Canvas – ללא שינוי |
| שמירת ציור (PNG) לטלפון | `cordova-bridge.js` → Cordova File plugin → תיקיית Downloads |
| פתיחת תמונה מהגלריה | `cordova-plugin-camera` (PHOTOLIBRARY) |
| גיבוי / ייצוא JSON | Cordova File → Downloads |
| ייבוא גיבוי JSON | `<input type=file>` (WebView) |
| שמירה אוטומטית ב-IndexedDB | WebView localStorage / IDB – עובד כמו בדפדפן |
| חותך (Cutter) | ללא שינוי |
| זום, לחיצה, העברה | ללא שינוי |

---

## עדכון הקוד (HTML)

כשיש גרסה חדשה של `draw_canvas_*.html`:

```bash
# העתק את הקובץ החדש
cp /path/to/draw_canvas_new.html www/index.html

# ודא שהשורות הבאות קיימות לפני </head> ב-index.html:
# <script src="cordova.js"></script>
# <script src="cordova-bridge.js"></script>

# בנה מחדש
cordova build android
```

---

## פתרון בעיות

**הורדת קבצים לא עובדת:**
- ודא שהרשות `WRITE_EXTERNAL_STORAGE` אושרה בהגדרות האפליקציה
- ב-Android 13+ נדרשת `READ_MEDIA_IMAGES` במקום `READ_EXTERNAL_STORAGE`

**גלריה לא נפתחת:**
- ודא שה-plugin camera מותקן: `cordova plugin list`
- ב-Android 13+ הרשות לגלריה היא `READ_MEDIA_IMAGES`

**הודעת "cordova.js not found" בדפדפן:**
- זה נורמלי – `cordova.js` קיים רק ב-APK. ה-bridge מתנהג ללא שגיאות בדפדפן רגיל.

---

## מבנה הפרויקט

```
justdraw-apk/
├── config.xml              ← הגדרות Cordova (ID, plugins, permissions)
├── package.json            ← תלויות npm
├── BUILD_INSTRUCTIONS.md   ← מסמך זה
├── www/
│   ├── index.html          ← האפליקציה המלאה
│   ├── cordova-bridge.js   ← גשר לפונקציות native
│   ├── icon.png            ← אייקון האפליקציה (512x512)
│   └── splash.png          ← מסך פתיחה (1920x1080)
└── platforms/              ← נוצר אוטומטית ע"י Cordova (לא לגעת)
```

---

## App ID & גרסה

- **Bundle ID:** `online.jacobi.justdraw`
- **גרסה:** `1.0.0`
- **Android minSdk:** 24 (Android 7.0+)
- **Android targetSdk:** 34 (Android 14)

לשינוי, ערוך את `config.xml`.
