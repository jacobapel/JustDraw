/**
 * JustDraw – Cordova Bridge
 * Patches browser APIs so the app works natively on Android.
 *
 * Loaded BEFORE the main HTML logic via <script src="cordova-bridge.js">.
 * The main cordova.js is loaded by Cordova automatically at runtime.
 *
 * What this file does:
 *  1. Waits for deviceready then sets window._cordovaReady = true
 *  2. Patches saveFileNative() – replaces <a download> with Cordova File write to Downloads
 *  3. Patches loadImageFromDevice() – opens gallery via Camera plugin
 *  4. Patches exportBackup() / importBackup() – JSON backup via Cordova File
 */

(function () {
  'use strict';

  /* ── 1. deviceready ───────────────────────────────────────────── */
  window._cordovaReady = false;
  document.addEventListener('deviceready', function () {
    window._cordovaReady = true;
    console.log('[Bridge] Cordova ready');
  }, false);

  /* helper: wait for deviceready before running cb */
  function onReady(cb) {
    if (window._cordovaReady) { cb(); return; }
    document.addEventListener('deviceready', cb, { once: true });
  }

  /* ── 2. Save file to Downloads ───────────────────────────────── */
  /**
   * Call this instead of a dynamic <a download> link.
   * filename : e.g. "drawing.png"  or  "backup.json"
   * dataURL  : data:image/png;base64,…  or  data:application/json;base64,…
   * mimeType : 'image/png' | 'application/json' | 'text/html' etc.
   */
  window.cordovaSaveFile = function (filename, dataURL, mimeType) {
    onReady(function () {
      // Convert dataURL → Blob → ArrayBuffer
      var b64 = dataURL.split(',')[1];
      var binary = atob(b64);
      var len = binary.length;
      var bytes = new Uint8Array(len);
      for (var i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
      var ab = bytes.buffer;

      // Write to external (Downloads) directory
      var dir = cordova.file.externalRootDirectory + 'Download/';
      window.resolveLocalFileSystemURL(dir, function (dirEntry) {
        dirEntry.getFile(filename, { create: true, exclusive: false }, function (fileEntry) {
          fileEntry.createWriter(function (writer) {
            writer.onwriteend = function () {
              console.log('[Bridge] Saved: ' + fileEntry.nativeURL);
              // Try to open / share the file
              try {
                cordova.plugins.fileOpener2.open(
                  fileEntry.nativeURL,
                  mimeType,
                  { error: function (e) { console.warn('[Bridge] open error', e); } }
                );
              } catch (ex) { /* plugin missing – ignore */ }
            };
            writer.onerror = function (e) { console.error('[Bridge] write error', e); };
            writer.write(new Blob([ab], { type: mimeType }));
          });
        }, function (e) { console.error('[Bridge] getFile error', e); });
      }, function (e) { console.error('[Bridge] resolveLocalFileSystemURL error', e); });
    });
  };

  /* ── 3. Load image from gallery ─────────────────────────────── */
  /**
   * Opens the gallery and calls back with a dataURL string.
   * onSuccess(dataURL)  onError(msg)
   */
  window.cordovaPickImage = function (onSuccess, onError) {
    onReady(function () {
      navigator.camera.getPicture(
        function (base64) {
          onSuccess('data:image/jpeg;base64,' + base64);
        },
        function (err) {
          if (onError) onError(err);
        },
        {
          quality: 90,
          destinationType: Camera.DestinationType.DATA_URL,
          sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
          encodingType: Camera.EncodingType.JPEG,
          correctOrientation: true
        }
      );
    });
  };

  /* ── 4. Patch window.saveAs / download-anchor behaviour ─────── */
  /*
   * The main HTML uses patterns like:
   *   const a = document.createElement('a');
   *   a.href = canvas.toDataURL(...);
   *   a.download = 'drawing.png';
   *   a.click();
   *
   * On Android WebView, a.click() on a data: URL does nothing.
   * We intercept by overriding HTMLAnchorElement.click when href is data:
   */
  var _origClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (this.download && this.href && this.href.startsWith('data:')) {
      var mime = this.href.split(';')[0].replace('data:', '') || 'application/octet-stream';
      var fname = this.download || 'file';
      window.cordovaSaveFile(fname, this.href, mime);
      return; // don't call original
    }
    _origClick.call(this);
  };

  /* Also patch dispatchEvent('click') path used by some code */
  var _origDispatch = EventTarget.prototype.dispatchEvent;
  EventTarget.prototype.dispatchEvent = function (ev) {
    if (ev.type === 'click' && this instanceof HTMLAnchorElement &&
        this.download && this.href && this.href.startsWith('data:')) {
      var mime = this.href.split(';')[0].replace('data:', '') || 'application/octet-stream';
      window.cordovaSaveFile(this.download || 'file', this.href, mime);
      return true;
    }
    return _origDispatch.call(this, ev);
  };

  /* ── 5. File input override: prefer gallery picker on Android ── */
  /*
   * <input type="file" accept="image/*"> is often broken in old Cordova WebViews.
   * We intercept clicks on such inputs and use the Camera plugin instead.
   * The bridge calls back into the app by faking a file-change event… but that
   * requires injecting a File object, which is complex.  The simpler approach:
   * set window._cordovaImagePickerCb before click, then call cordovaPickImage.
   *
   * The main HTML's uploadFileInput handler already handles dataURL if we
   * provide one; we just need to set the right property before the event fires.
   *
   * NOTE: If the existing <input type=file> works fine in the WebView, this
   * patch stays dormant (we only activate it if navigator.camera is available
   * AND the standard input is known broken).  Test first without this patch.
   */

  console.log('[Bridge] cordova-bridge.js loaded');
})();
