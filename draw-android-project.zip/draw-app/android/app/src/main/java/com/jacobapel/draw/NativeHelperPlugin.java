package com.jacobapel.draw;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.OutputStream;

@CapacitorPlugin(name = "NativeHelper")
public class NativeHelperPlugin extends Plugin {

    /**
     * Saves a file (given as base64) into the public Download folder. Android 10+.
     * params: name, base64, mime
     * Resolves with { name } - the final file name (Android may append " (1)" if it already exists).
     */
    @PluginMethod
    public void saveToDownloads(PluginCall call) {
        String name = call.getString("name");
        String b64 = call.getString("base64");
        String mime = call.getString("mime", "application/octet-stream");
        if (name == null || b64 == null) {
            call.reject("missing name or data");
            return;
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            call.reject("requires Android 10 or newer");
            return;
        }
        try {
            byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
            ContentResolver resolver = getContext().getContentResolver();
            Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;

            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            Uri target = resolver.insert(collection, values);
            if (target == null) {
                call.reject("could not create file");
                return;
            }
            OutputStream os = resolver.openOutputStream(target, "wt");
            if (os == null) {
                call.reject("could not open file");
                return;
            }
            try {
                os.write(bytes);
            } finally {
                os.close();
            }
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage() == null ? "save failed" : e.getMessage());
        }
    }
}
