# לוח ציור — אפליקציית אנדרואיד (APK)

אפליקציית "לוח ציור" (JustDraw) עטופה כ-APK באמצעות Capacitor. הקוד של האפליקציה נמצא ב-`www/index.html`.

## מה זה
- שם חבילה: `com.jacobapel.draw`, שם תצוגה: "לוח ציור", גרסה 1.0 (versionCode 1).
- GitHub Actions בונה את ה-APK. אין צורך ב-Android Studio.
- מפתח חתימה קבוע (`android/app/debug.keystore`), כך שגרסאות עתידיות מותקנות מעל הקודמות בלי לאבד ציורים. הרפוזיטורי חייב להיות Private.

## מה שונה מהגרסה ל-Chrome
| נושא | באפליקציה |
|---|---|
| שמירת תמונה, ייצוא הגדרות, העתקה כשאין לוח | מתבצעים דרך שכבה (shim) שתופסת כל `<a download>` עם blob/data ושומרת ל-**Download** של הטלפון דרך התוסף `NativeHelper` (Android 10+) |
| גופן Heebo | נארז בתוך האפליקציה (`www/fonts`) ולכן עובד בלי אינטרנט |
| כפתור "אחורה" | מציג "לצאת מלוח הציור?" ובאישור סוגר את האפליקציה. הורדת `ציור.png` בכל לחיצה בוטלה כי יש שמירה אוטומטית ב-IndexedDB |
| שמירת סדר הכפתורים לקובץ HTML | באפליקציה הסדר נשמר ב-localStorage בלבד |
| אזורים בטוחים (חריץ, פס ניווט) | `env(safe-area-inset-*)` עם גיבוי למשתני Capacitor |
| `prompt()` / `confirm()` / בחירת קובץ | פועלים דרך WebView של Capacitor |
| PWA manifest | נשאר בקוד ואינו מזיק |

כל קוד ההתאמה מופעל רק כש-`Capacitor.isNativePlatform()`. אותו `index.html` ממשיך לעבוד כרגיל בדפדפן.

## בנייה מהטלפון
1. צור ב-GitHub רפוזיטורי **פרטי** חדש, למשל `JustDraw`.
2. העלה אליו את קובץ ה-zip **כמו שהוא** (`draw-android-project.zip`), ב-Add file ← Upload files.
3. צור את `.github/workflows/build.yml` (Add file ← Create new file) והדבק את תוכן הקובץ `repo-root-workflow/build.yml` שבתוך ה-zip. הקובץ פותח את ה-zip לתיקיית `src` ובונה.
4. ב-Actions המתן ל-✓ ירוק (5 עד 10 דקות), היכנס להרצה והורד מ-Artifacts את `justdraw-apk`.
5. פתח את ה-zip, והתקן את `app-debug.apk`. אשר "התקנה ממקורות לא ידועים".

## עדכון בעתיד
- שנה את `www/index.html` (ואם צריך הגדל `versionCode` ו-`versionName` ב-`android/app/build.gradle`), ארוז מחדש לאותו שם zip והעלה ב-Add file ← Upload files. הבנייה רצה אוטומטית.
- כדי לעבוד על הקוד בשיחת הציור: שמור שם את `www/index.html` החדש והעבר אותו לכאן כקובץ HTML. ההתאמות לאפליקציה כבר בתוכו, ואין צורך לשנות אותן.

## מגבלות ידועות
- שמירה ל-Download דורשת אנדרואיד 10 ומעלה.
- העתקת תמונה ללוח (clipboard) תלויה בגרסת ה-WebView. אם נכשלה, התמונה נשמרת לקובץ.
- לא נבדק בבנייה אמיתית בסביבת העבודה (אין שם Android SDK), והבדיקה הראשונה תהיה ב-GitHub Actions.
